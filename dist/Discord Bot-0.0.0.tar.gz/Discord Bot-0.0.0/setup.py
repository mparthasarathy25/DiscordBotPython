from setuptools import _install_setup_requires, setup, find_packages

setup(
    name = 'Discord Bot',
    author = 'Madhav Parthasarathy',
    packages = find_packages(),
    install_requires = ['']
)