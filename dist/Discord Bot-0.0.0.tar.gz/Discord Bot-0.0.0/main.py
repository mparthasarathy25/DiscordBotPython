from discord import File, Embed
from discord.ext import commands, tasks
from sqlite3 import connect
from datetime import datetime, timedelta, date
from matplotlib.pyplot import xticks, yticks, xlabel, ylabel, show, close, bar, savefig, plot
from numpy import arange
from io import BytesIO
from os import remove, path, environ
from pandas import Index, DataFrame, read_csv, concat
from requests import get
from random import randint
import unittest as ut

#commit
client = commands.Bot(command_prefix = '$', case_insensitive = True)

ticker_data = read_csv('tickers.csv')
for element in range(len(ticker_data)):
        globals()[f"count_{element}"] = 0
        globals()[f"count_{element}_unique"] = 0

@client.event
async def on_ready():
    ticker_data = read_csv('tickers.csv')
    db = connect('sigma7.sqlite')
    cursor = db.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sigma7(
        member TEXT,
        message TEXT,
        date TEXT,
        keyword TEXT
        )
    ''')
    clear = ("DELETE FROM sigma7")
    cursor.execute(clear)
    market_channel = client.get_channel(852551268056825879)
    chat_channel = client.get_channel(852554104508121119)
    async for msg in market_channel.history(limit=10000): # As an example, I've set the limit to 10000
        if not msg.author.bot:
            time = msg.created_at
            sql = ("INSERT INTO sigma7(member, message, date) VALUES(?,?,?)")
            val = (str(msg.author), str(msg.content), time.strftime('%Y-%m-%d %H:%M:%S')) 
            cursor.execute(sql,val)
    async for msg in chat_channel.history(limit=10000): # As an example, I've set the limit to 10000
        if not msg.author.bot:
            time = msg.created_at
            sql = ("INSERT INTO sigma7(member, message, date) VALUES(?,?,?)")
            val = (str(msg.author), str(msg.content), time.strftime('%Y-%m-%d %H:%M:%S')) 
            cursor.execute(sql,val)
    channel = client.get_channel(854077038514929687)
    # async for msg in channel.history(limit=10000): # As an example, I've set the limit to 10000
    #     if not msg.author.bot:
    #         time = msg.created_at
    #         sql = ("INSERT INTO sigma7(member, message, date) VALUES(?,?,?)")
    #         val = (str(msg.author), str(msg.content), time.strftime('%Y-%m-%d %H:%M:%S')) 
    #         cursor.execute(sql,val)
    msg_authors = []
    async for msg in market_channel.history(limit = 10000, after = datetime.now() + timedelta(hours=5) - timedelta(weeks=2)):
        if not msg.author.bot:
            for element in range(len(ticker_data)):
                if ticker_data.get('Symbol')[element] == msg.content:
                    if msg.author not in msg_authors:
                        msg_authors.append(msg.author)
                        globals()[f"count_{element}_unique"] += 1
                        break
                    globals()[f"count_{element}"] += 1
                else:
                    for i in range(len(msg.content.split())):
                        if ticker_data.get('Symbol')[element] == msg.content.split()[i]:
                            if msg.author not in msg_authors:
                                msg_authors.append(msg.author)
                                globals()[f"count_{element}_unique"] += 1
                            globals()[f"count_{element}"] += 1
    async for msg in chat_channel.history(limit = 10000, after = datetime.now() + timedelta(hours=5) - timedelta(weeks=2)):
        if not msg.author.bot:
            for element in range(len(ticker_data)):
                if ticker_data.get('Symbol')[element] == msg.content:
                    if msg.author not in msg_authors:
                        msg_authors.append(msg.author)
                        globals()[f"count_{element}_unique"] += 1
                        break
                    globals()[f"count_{element}"] += 1
                else:
                    for i in range(len(msg.content.split())):
                        if ticker_data.get('Symbol')[element] == msg.content.split()[i]:
                            if msg.author not in msg_authors:
                                msg_authors.append(msg.author)
                                globals()[f"count_{element}_unique"] += 1
                            globals()[f"count_{element}"] += 1
                            

    # async for msg in channel.history(limit = None, after = datetime.datetime.now() + datetime.timedelta(hours=5) - datetime.timedelta(weeks=2)):
    #     if not msg.author.bot:
    #         for element in range(len(ticker_data)):
    #             for i in range(len(msg.content.split())):
    #                 if ticker_data.get('Symbol')[element] == msg.content.split()[i]:
    #                     globals()[f"count_{element}"] += 1
    #                     break

    db.commit()
    cursor.close()
    db.close()  
    counter.start()
    trendcounter.start()

@tasks.loop(minutes = 60)
async def trendcounter():
    ticker_data = read_csv('tickers.csv')
    for element in range(len(ticker_data)):
        globals()[f"count_{element}"] = 0
    market_channel = client.get_channel(852551268056825879)
    chat_channel = client.get_channel(852554104508121119)
    channel = client.get_channel(854077038514929687)
    msg_authors = []
    async for msg in market_channel.history(limit = 10000, after = datetime.now() + timedelta(hours=5) - timedelta(weeks=2)):
        if not msg.author.bot:
            for element in range(len(ticker_data)):
                if ticker_data.get('Symbol')[element] == msg.content:
                    if msg.author not in msg_authors:
                        msg_authors.append(msg.author)
                        globals()[f"count_{element}_unique"] += 1
                        break
                    globals()[f"count_{element}"] += 1
                else:
                    for i in range(len(msg.content.split())):
                        if ticker_data.get('Symbol')[element] == msg.content.split()[i]:
                            if msg.author not in msg_authors:
                                msg_authors.append(msg.author)
                                globals()[f"count_{element}_unique"] += 1
                            globals()[f"count_{element}"] += 1
    async for msg in chat_channel.history(limit = 10000, after = datetime.now() + timedelta(hours=5) - timedelta(weeks=2)):
        if not msg.author.bot:
            for element in range(len(ticker_data)):
                if ticker_data.get('Symbol')[element] == msg.content:
                    if msg.author not in msg_authors:
                        msg_authors.append(msg.author)
                        globals()[f"count_{element}_unique"] += 1
                        break
                    globals()[f"count_{element}"] += 1
                else:
                    for i in range(len(msg.content.split())):
                        if ticker_data.get('Symbol')[element] == msg.content.split()[i]:
                            if msg.author not in msg_authors:
                                msg_authors.append(msg.author)
                                globals()[f"count_{element}_unique"] += 1
                            globals()[f"count_{element}"] += 1
    # async for msg in channel.history(limit = 10000, after = datetime.datetime.now() + datetime.timedelta(hours=5) - datetime.timedelta(weeks=2)):
    #     if not msg.author.bot:
    #         for element in range(len(ticker_data)):
    #             for i in range(len(msg.content.split())):
    #                 if ticker_data.get('Symbol')[element] == msg.content.split()[i]:
    #                     globals()[f"count_{element}"] += 1
    #                     break

@tasks.loop(minutes = 5)
async def counter():
    ticker_data = read_csv('tickers.csv')
    db = connect('sigma7.sqlite')
    cursor = db.cursor()
    market_channel = client.get_channel(852551268056825879)
    chat_channel = client.get_channel(852554104508121119)
    channel = client.get_channel(854077038514929687)
    async for msg in market_channel.history(limit = 10000, after = datetime.now() + timedelta(hours=5) - timedelta(minutes=5)):
        if not msg.author.bot:
            time = msg.created_at
            sql = ("INSERT INTO sigma7(member, message, date) VALUES(?,?,?)")
            val = (str(msg.author), str(msg.content), time.strftime('%Y-%m-%d %H:%M:%S')) 
            cursor.execute(sql,val)
    async for msg in chat_channel.history(limit = 10000, after = datetime.now() + timedelta(hours=5) - timedelta(minutes=5)):
        if not msg.author.bot:
            time = msg.created_at
            sql = ("INSERT INTO sigma7(member, message, date) VALUES(?,?,?)")
            val = (str(msg.author), str(msg.content), time.strftime('%Y-%m-%d %H:%M:%S')) 
            cursor.execute(sql,val)
    # async for msg in channel.history(limit = None, after = datetime.datetime.now() + datetime.timedelta(hours=5) - datetime.timedelta(minutes=5)):
    #     if not msg.author.bot:
    #         time = msg.created_at
    #         sql = ("INSERT INTO sigma7(member, message, date) VALUES(?,?,?)")
    #         val = (str(msg.author), str(msg.content), time.strftime('%Y-%m-%d %H:%M:%S')) 
    #         cursor.execute(sql,val)
    db.commit()
    cursor.close()
    db.close()  

# def trending_unique():
#     x_trends = (first_trend, second_trend, third_trend, fourth_trend, fifth_trend)
#     pos = arange(len(x_trends))
#     numbers = [new_list[0],new_list[1],new_list[2],new_list[3],new_list[4]]
#     bar(pos, numbers, align = 'center')
#     xticks(pos, x_trends, color = 'white')
#     yticks(color = 'white')
#     ylabel('Number of Messages', color = 'white')
#     savefig('trend_image.png', transparent = True)
#     close()
#     with open('trend_image.png', 'rb') as f:
#         file = BytesIO(f.read())
    
#     image = File(file, filename = 'trend.png')
#     trending_embed = Embed(title = "Trending Stocks on Discord")
#     trending_embed.set_image(url = 'attachment://trend.png')
#     if path.exists('trend_image.png'):
#         remove('trend_image.png')
#     trending_embed.add_field(name = ("1. " + first_trend), value = ticker_data['Name'][company_index1].split()[0], inline = False)
#     trending_embed.add_field(name = ("2. " + second_trend), value = ticker_data['Name'][company_index2].split()[0], inline = False)
#     trending_embed.add_field(name = ("3. " + third_trend), value = ticker_data['Name'][company_index3].split()[0], inline = False)
#     trending_embed.add_field(name = ("4. " + fourth_trend), value = ticker_data['Name'][company_index4].split()[0], inline = False)
#     trending_embed.add_field(name = ("5. " + fifth_trend), value = ticker_data['Name'][company_index5].split()[0], inline = False)
#     return_list = [trending_embed, image]
#     return return_list

@client.command()
async def trending(ctx: commands.Context):
    ticker_data = read_csv('tickers.csv')
    db = connect('sigma7.sqlite')
    cursor = db.cursor()  
    currentDate = date.today()
    days = timedelta(14)
    pastDate = currentDate - days
    cursor.execute("SELECT message FROM sigma7 WHERE CAST(date as DATE) >= CAST(" + pastDate.strftime('%Y-%m-%d') + " as DATE)")
    result3 = cursor.fetchall()
    db.commit()
    cursor.close()
    list = []
    first_trend = ""
    second_trend = ""
    third_trend = ""
    fourth_trend = ""
    fifth_trend = ""
    for element in range(len(ticker_data)):
        list.append(globals()[f"count_{element}"])
    list.sort(reverse = True)
    new_list = list.copy()
    for element in range(len(ticker_data)):
        if globals()[f"count_{element}"] == list[0]:
            first_trend = ticker_data.get('Symbol')[element]
            list[0] = -1
        elif globals()[f"count_{element}"] == list[1]:
            second_trend = ticker_data.get('Symbol')[element]
            list[1] = -1
        elif globals()[f"count_{element}"] == list[2]:
            third_trend = ticker_data.get('Symbol')[element]
            list[2] = -1
        elif globals()[f"count_{element}"] == list[3]:
            fourth_trend = ticker_data.get('Symbol')[element]
            list[3] = -1
        elif globals()[f"count_{element}"] == list[4]:
            fifth_trend = ticker_data.get('Symbol')[element]
            list[4] = -1

    data_index = Index(ticker_data['Symbol'])
    company_index1 = data_index.get_loc(first_trend)
    company_index2 = data_index.get_loc(second_trend)
    company_index3 = data_index.get_loc(third_trend)
    company_index4 = data_index.get_loc(fourth_trend)
    company_index5 = data_index.get_loc(fifth_trend)
    x_trends = (first_trend, second_trend, third_trend, fourth_trend, fifth_trend)
    pos = arange(len(x_trends))
    numbers = [new_list[0],new_list[1],new_list[2],new_list[3],new_list[4]]
    bar(pos, numbers, align = 'center')
    xticks(pos, x_trends, color = 'white')
    yticks(color = 'white')
    ylabel('Number of Messages', color = 'white')
    savefig('trend_image.png', transparent = True)
    close()
    with open('trend_image.png', 'rb') as f:
        file = BytesIO(f.read())
    
    image =File(file, filename = 'trend.png')
    trending_embed = Embed(title = "Trending Stocks on Discord")
    trending_embed.set_image(url = 'attachment://trend.png')
    if path.exists('trend_image.png'):
        remove('trend_image.png')
    trending_embed.add_field(name = ("1. " + first_trend), value = ticker_data['Name'][company_index1].split()[0], inline = False)
    trending_embed.add_field(name = ("2. " + second_trend), value = ticker_data['Name'][company_index2].split()[0], inline = False)
    trending_embed.add_field(name = ("3. " + third_trend), value = ticker_data['Name'][company_index3].split()[0], inline = False)
    trending_embed.add_field(name = ("4. " + fourth_trend), value = ticker_data['Name'][company_index4].split()[0], inline = False)
    trending_embed.add_field(name = ("5. " + fifth_trend), value = ticker_data['Name'][company_index5].split()[0], inline = False)
    await ctx.send(embed = trending_embed, file = image)


def get_historic_data(symbol, length, method):
    ticker = symbol
    iex_api_key = 'Tsk_30a2677082d54c7b8697675d84baf94b'
    api_url = f'https://sandbox.iexapis.com/stable/stock/{ticker}/chart/{length}?token={iex_api_key}'
    df = get(api_url).json()
    
    date = []
    open = []
    high = []
    low = []
    close1 = []
    
    for i in range(len(df)):
        date.append(df[i]['date'])
        open.append(df[i]['open'])
        high.append(df[i]['high'])
        low.append(df[i]['low'])
        close1.append(df[i]['close'])
    
    date_df = DataFrame(date).rename(columns = {0:'date'})
    open_df = DataFrame(open).rename(columns = {0:'open'})
    high_df = DataFrame(high).rename(columns = {0:'high'})
    low_df = DataFrame(low).rename(columns = {0:'low'})
    close_df = DataFrame(close1).rename(columns = {0:'close'})
    
    frames = [date_df, open_df, high_df, low_df, close_df]
    df = concat(frames, axis = 1, join = 'inner')
    df = df.set_index('date')
    
    df[method].plot()
    xlabel('Date', fontsize = 10, color = 'white')
    ylabel('Price', fontsize = 10, color = 'white')
    xticks(fontsize = 8, color = 'white')
    yticks(fontsize = 10, color = 'white')
    savefig('stock_image.png', transparent = True)
    close()

@client.command()
async def stock(ctx: commands.Context, company_name, option, method = '', length = ''):
    # ticker = yf.Ticker(company_name)
    # delta = datetime.timedelta(days = 30)
    # delta1 = datetime.timedelta(days = 1)
    # dates = drange(date.today()-delta, date.today(), delta1)
    # prices = ticker.history(period = "30d").get('Open')
    if option == 'graph':
        if method != '':
            if length != '':
                get_historic_data(company_name, length, method)
                embed = Embed(title= method.capitalize() + ' Price Change Of ' + company_name + ' Over The Last ' + length, colour= 0x00b2ff)
                with open('stock_image.png', 'rb') as f:
                    file = BytesIO(f.read())
                if path.exists('stock_image.png'):
                    remove('stock_image.png')
                image = File(file, filename='graph' + company_name + '.png')
                embed.set_image(url=f'attachment://graph' + company_name + '.png')
                await ctx.send(embed=embed,file=image)
    elif option == 'updates':
        ticker = company_name
        # IEX_KEY = ""
        # token = environ["IEX_KEY"]
        iex_api_key = 'Tsk_0b9207a29bb6409dad0c0fe34c82a2ab'
        api_url = f'https://sandbox.iexapis.com/stable/stock/{ticker}/quote/?token={iex_api_key}'
        df = get(api_url).json()
        embed = Embed(title='Latest Updates of ' + ticker, colour= 0x00b2ff)
        embed.add_field(name = "Symbol : " + str(df['symbol']), value = "Latest Price : " + str(df['latestPrice']) + "\n" + "Market Cap : " + str(df['marketCap']) + "\n" + "Percent Change (from last close) : " + str(df['changePercent']))
        await ctx.send(embed = embed)


api = '3c3wFYiCLgsFup0dHv0p4kxJnSVx_mrG'
@client.command()
async def news(ctx: commands.Context, company_name, number: int = 5):
    ticker_data = read_csv('tickers.csv')
    data_index = Index(ticker_data['Symbol'])
    company_index = data_index.get_loc(company_name)
    ticker = company_name
    limit = '100'
    api_url = f'https://api.polygon.io/v2/reference/news?limit={limit}&order=descending&sort=published_utc&ticker={ticker}&published_utc.gte=2021-04-26&apiKey={api}'
    data = get(api_url).json()
    count = 0
    for element in data['results']:
        if count >= number:
            break
        if (ticker_data['Name'][company_index].split()[0].lower()) in element['article_url']:
            try: 
                element['description']
            except KeyError:
                discord_embed = Embed(title= element['title'], url= element['article_url'])
            else:
                discord_embed = Embed(title= element['title'], url= element['article_url'],  description = element['description'])
            try:
                element['image_url']
            except KeyError:
                continue
            else:
                discord_embed.set_image(url = element['image_url'])
            await ctx.send(embed = discord_embed)
            count += 1

def truncate(n, decimals=0):
    multiplier = 10 ** decimals
    return int(n * multiplier) / multiplier

member_list = []
portfolio_list = []
@client.command()
async def portfolio(ctx: commands.Context, option, *, items=''):
    stock_list = []
    portfolio_embed = Embed(title = "Your Portfolio")
    member_list.append(ctx.author.display_name)
    for i in range(len(member_list)):
        portfolio_list.append(i)
    if option == "create":
        if len(items.split()) != 0:
            for i in range(len(items.split())):
                if i % 2 == 0:  
                    iex_api_key = 'Tsk_0b9207a29bb6409dad0c0fe34c82a2ab'
                    api_url = f'https://sandbox.iexapis.com/stable/stock/{items.split()[i]}/quote/?token={iex_api_key}'
                    df = get(api_url).json()
                    portfolio_embed.add_field(name = (items.split()[i+1] + " shares of " + items.split()[i]), value = "$" + str(truncate((int(items.split()[i+1])*int(df['latestPrice'])), 2)), inline = True)
                    stock_list.append(items.split()[i])
        portfolio_list.append(portfolio_embed)
        portfolio_list[member_list.index(ctx.author.display_name)] = portfolio_embed
        await ctx.author.send(embed = portfolio_list[member_list.index(ctx.author.display_name)])
    elif option == "update":
        count = 0 
        if len(items.split()) != 0:
            for i in range(len(items.split())):
                if items.split()[i] == "add":
                    for item in items.split()[(i+1):]:
                        if item == "remove":
                            break
                        elif i+1 % 2 == 0:
                            if items.split().index(item) % 2 == 0:
                                iex_api_key = 'Tsk_0b9207a29bb6409dad0c0fe34c82a2ab'
                                api_url = f'https://sandbox.iexapis.com/stable/stock/{items.split()[items.split().index(item)]}/quote/?token={iex_api_key}'
                                df = get(api_url).json()
                                portfolio_list[member_list.index(ctx.author.display_name)].add_field(name = (items.split()[items.split().index(item)+1] + " shares of " + items.split()[items.split().index(item)]), value = "$" + str(truncate(int(items.split()[items.split().index(item)+1])*df['latestPrice'], 2)), inline = True)
                        elif i+1 % 2 == 1:
                            if items.split().index(item) % 2 == 1:
                                iex_api_key = 'Tsk_0b9207a29bb6409dad0c0fe34c82a2ab'
                                api_url = f'https://sandbox.iexapis.com/stable/stock/{items.split()[items.split().index(item)]}/quote/?token={iex_api_key}'
                                df = get(api_url).json()
                                portfolio_list[member_list.index(ctx.author.display_name)].add_field(name = (items.split()[items.split().index(item)+1] + " shares of " + items.split()[items.split().index(item)]), value = "$" + str(truncate(int(items.split()[items.split().index(item)+1])*df['latestPrice'], 2)), inline = True)            

                elif items.split()[i] == "remove":
                    for item in items.split()[(i+1):]:
                        if item == "add":
                            break
                        elif count == 0:
                            portfolio_list[member_list.index(ctx.author.display_name)].remove_field(int(item) - 1)
                            count += 1
                        elif count > 0:
                            portfolio_list[member_list.index(ctx.author.display_name)].remove_field(int(item) - 1 - count)
                            count += 1


        await ctx.author.send(embed = portfolio_list[member_list.index(ctx.author.display_name)])


    elif option == "view":
        await ctx.author.send(embed = portfolio_list[member_list.index(ctx.author.display_name)])

@client.command()
async def roll(ctx: commands.Context, number: int = 6):
    await ctx.send("Here's your lucky number: " + str(randint(1,number)))

@client.command()
async def description(ctx: commands.Context, company_name):
    iex_api_key = 'Tsk_0b9207a29bb6409dad0c0fe34c82a2ab'
    api_url = f'https://sandbox.iexapis.com/stable/stock/{company_name}/company/?token={iex_api_key}'
    df = get(api_url).json()
    desc_embed = Embed(title = company_name)
    desc_embed.add_field(name = 'Description', value = df['description'])
    await ctx.send(embed = desc_embed)
    
@client.command()
async def allcommands(ctx: commands.Context):
    command_embed = Embed(title = 'Available Commands')
    command_embed.add_field(name = 'Command List: ', value = '$trending \n$news tickername numberofarticles \n$stock tickername (graph or updates) (if graph, choose what to graph: low, high, close, open) (if graph, choose time period: 5d, 1m, 3m, 1y)  \n$portfolio (create or update or view) (if create, input the ticker followed by how many shares owned; ex: AAPL 2 MSFT 3) <- (If update instead of create, input add (add MSFT 3 NFLX 2) or remove (remove 1, will remove first stock in portfolio) \n$description tickername \n$roll number')
    command_embed.add_field(name = 'Examples: ', value = 'Examples: \n$trending \n$news AAPL 3 \n$stock GS updates \n$stock GS graph low 3d \n$portfolio create MSFT 3 GOOGL 5 AA 2 \n$portfolio update add AAPL 3 \n$portfolio update remove 1 \n$portfolio update add NFLX 2 remove 2 \n$portfolio view \n$description NFLX \n$roll 6')
    await ctx.send(embed = command_embed)
    
@client.command()
async def purge(self, ctx, *, number:int=None):
    if ctx.message.author.guild_permissions.manage_messages:
        try:
            if number is None:
                await ctx.send("You must input a number")
            else:
                deleted = await ctx.message.channel.purge(limit = number)
                await ctx.send(f"Messages purged by {ctx.message.author.mention}: '{len(deleted)}'")
        except:
            await ctx.send("I can't purge messages here.")
    else:
        await ctx.send("You do not have permissions to use this command.")

@client.event
async def on_command_error(ctx: commands.Context, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send("I'm not sure what that means...")
    # else:
    #     pass

@portfolio.error
async def portfolio_error(ctx: commands.Context, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("I think you're missing something...")
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send("I think you typed something wrong...")

@stock.error
async def stock_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("I think you're missing something...")
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send("I think you typed something wrong...")

@news.error
async def news_error(ctx: commands.Context, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("I think you're missing something...")
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send("I think you typed something wrong...")

@roll.error
async def roll_error(ctx: commands.Context, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("I think you're missing something...")
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send("I think you typed something wrong...")

@description.error
async def description_error(ctx: commands.Context, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("I think you're missing something...")
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send("I think you typed something wrong...")

# def assertions():
#     ut.assertEqual(doc)

client.run('ODUzODY1MDkyNTg4NjM0MTMz.YMbl1g.NR_nKTOXqiP4NBwpov9zw-mFYtU')
